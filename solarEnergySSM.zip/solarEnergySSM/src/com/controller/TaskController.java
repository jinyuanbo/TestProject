package com.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.Equipment;
import com.model.Task;
import com.service.EquipmentService;
import com.service.TaskService;
import com.util.DateUtil;

@Controller
@RequestMapping("/task")
public class TaskController {

	@Autowired
	private TaskService taskService;
	
	@Autowired
	private EquipmentService equipmentService;
	
	@RequestMapping("/findTaskAll")
	public String findTaskAll(HttpServletRequest request) {
		String role = (String)request.getSession().getAttribute("roler");
		List<Task> taskList = null;
		if("1".equals(role)){
			Integer uid = (Integer)request.getSession().getAttribute("uid");
			taskList = taskService.findTaskAll(uid);
		}else{
			taskList = taskService.findTaskAll(null);
		}
		request.setAttribute("taskList", taskList);
		return "/task_list";
	}

	@RequestMapping("/beforeAddOrUpdateTask")
	public String beforeAddOrUpdateTask(Integer taskId,Integer equipmentId, HttpServletRequest request) {
		Task task = new Task();
		if (taskId != null && !taskId.equals("")) {
			task = taskService.findSingleTask(taskId);
		}
		request.setAttribute("task", task);
		request.setAttribute("equipmentId", equipmentId);
		
		return "/task_addOrEdit";
	}

	@RequestMapping("/addOrUpdateTask")
	public String addOrUpdateTask(Task task) {
		if(task.getTaskid()==null){
			task.setAddtime(DateUtil.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
			taskService.addTask(task);
		}else{
			taskService.updateTask(task);
		}
		return "redirect:/task/findTaskAll";
	}

	@RequestMapping("/deleteTask")
	public String deleteTask(Integer taskId) {
		taskService.deleteTask(taskId);
		return "redirect:/task/findTaskAll";
	}
	
	@RequestMapping("/updateStatus")
	public String updateStatus(Integer taskId,String status) {
		Task task = taskService.findSingleTask(taskId);
		task.setStatus(status);
		if("1".equals(status)){
			// 更新设备状态
			Equipment equipment = equipmentService.findSingleEquipment(task.getEquipmentid());
			equipment.setStatus("2");
			equipmentService.updateEquipment(equipment);
		}else if("3".equals(status)){
			// 更新设备状态
			Equipment equipment = equipmentService.findSingleEquipment(task.getEquipmentid());
			equipment.setStatus("0");
			equipmentService.updateEquipment(equipment);
		}
		taskService.updateTask(task);
		return "redirect:/task/findTaskAll";
	}
}
