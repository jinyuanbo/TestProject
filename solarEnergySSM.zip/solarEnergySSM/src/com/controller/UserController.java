package com.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.User;
import com.service.UserService;
import com.util.DateUtil;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;
	
	@RequestMapping("/login")
	public String login(String uname, String pwd,String role, HttpServletRequest request) {
		User user = userService.findUserByUsernameAndPwdAndRole(uname, pwd, role);
		if (user == null) {
			request.setAttribute("msg", "该用户不存在，请重新登录！");
			return "/login";
		} else {
			request.getSession().setAttribute("uname", user.getUsername());
			request.getSession().setAttribute("uid", user.getUserid());
			request.getSession().setAttribute("roler", user.getRole());
			request.setAttribute("msg", "");
			return "/index";
		}
	}
	
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) {
		request.getSession().setAttribute("uname", null); 
		request.getSession().setAttribute("uid", null);
		request.getSession().setAttribute("roler", null);
		request.setAttribute("msg", null);
		return "/login";
	}
	
	@RequestMapping("/regist")
	public String regist(User user, HttpServletRequest request) {
		userService.addUser(user);
		return "/login";
	}

	@RequestMapping("/findUserAll")
	public String findUserAll(String role,HttpServletRequest request) {
		List<User> userList = userService.findUserAll(role);
		request.setAttribute("userList", userList);
		request.setAttribute("role", role);
		return "/user_list";
	}

	@RequestMapping("/beforeAddOrUpdateUser")
	public String beforeAddOrUpdateUser(Integer userId,String role, HttpServletRequest request) {
		User user = new User();
		if (userId != null && !userId.equals("")) {
			user = userService.findSingleUser(userId);
		}
		request.setAttribute("user", user);
		request.setAttribute("role", role);
		return "/user_addOrEdit";
	}

	@RequestMapping("/addOrUpdateUser")
	public String addOrUpdateUser(User user, HttpServletRequest request) {
		if(user.getUserid()==null){
			user.setAddtime(DateUtil.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
			userService.addUser(user);
		}else{
			userService.updateUser(user);
		}
		return "redirect:/user/findUserAll?role="+user.getRole();
	}

	@RequestMapping("/deleteUser")
	public String deleteUser(Integer userId,String role) {
		userService.deleteUser(userId);
		return "redirect:/user/findUserAll?role="+role;
	}
}
