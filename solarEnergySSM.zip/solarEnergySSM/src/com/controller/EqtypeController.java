package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.Eqtype;
import com.service.EqtypeService;

@Controller
@RequestMapping("/eqtype")
public class EqtypeController {

	@Autowired
	private EqtypeService eqtypeService;
	
	@RequestMapping("/findEqtypeAll")
	public String findEqtypeAll(HttpServletRequest request) {
		List<Eqtype> eqtypeList = eqtypeService.findEqtypeAll();
		request.setAttribute("eqtypeList", eqtypeList);
		return "/eqtype_list";
	}

	@RequestMapping("/beforeAddOrUpdateEqtype")
	public String beforeAddOrUpdateEqtype(Integer eqtypeId, HttpServletRequest request) {
		Eqtype eqtype = new Eqtype();
		if (eqtypeId != null && !eqtypeId.equals("")) {
			eqtype = eqtypeService.findSingleEqtype(eqtypeId);
		}
		request.setAttribute("eqtype", eqtype);
		return "/eqtype_addOrEdit";
	}

	@RequestMapping("/addOrUpdateEqtype")
	public String addOrUpdateEqtype(Eqtype eqtype) {
		if(eqtype.getEqtypeid()==null){
			eqtypeService.addEqtype(eqtype);
		}else{
			eqtypeService.updateEqtype(eqtype);
		}
		return "redirect:/eqtype/findEqtypeAll";
	}

	@RequestMapping("/deleteEqtype")
	public String deleteEqtype(Integer eqtypeId) {
		eqtypeService.deleteEqtype(eqtypeId);
		return "redirect:/eqtype/findEqtypeAll";
	}
}
