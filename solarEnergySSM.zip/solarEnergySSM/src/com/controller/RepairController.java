package com.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.Equipment;
import com.model.Repair;
import com.service.EquipmentService;
import com.service.RepairService;
import com.util.DateUtil;

@Controller
@RequestMapping("/repair")
public class RepairController {

	@Autowired
	private RepairService repairService;
	
	@Autowired
	private EquipmentService equipmentService;
	
	@RequestMapping("/findRepairAll")
	public String findRepairAll(HttpServletRequest request) {
		String role = (String)request.getSession().getAttribute("roler");
		List<Repair> repairList = null;
		if("1".equals(role)){
			Integer uid = (Integer)request.getSession().getAttribute("uid");
			repairList = repairService.findRepairAll(uid);
		}else{
			repairList = repairService.findRepairAll(null);
		}
		request.setAttribute("repairList", repairList);
		return "/repair_list";
	}

	@RequestMapping("/beforeAddOrUpdateRepair")
	public String beforeAddOrUpdateRepair(Integer repairId,Integer equipmentId, HttpServletRequest request) {
		Repair repair = new Repair();
		if (repairId != null && !repairId.equals("")) {
			repair = repairService.findSingleRepair(repairId);
		}
		request.setAttribute("repair", repair);
		request.setAttribute("equipmentId", equipmentId);
		return "/repair_addOrEdit";
	}

	@RequestMapping("/addOrUpdateRepair")
	public String addOrUpdateRepair(Repair repair) {
		if(repair.getRepairid()==null){
			repair.setAddtime(DateUtil.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
			repairService.addRepair(repair);
			// 更新设备状态
			Equipment equipment = equipmentService.findSingleEquipment(repair.getEquipmentid());
			equipment.setStatus("1");
			equipmentService.updateEquipment(equipment);
		}else{
			repair.setReplytime(DateUtil.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
			repairService.updateRepair(repair);
			// 更新设备状态
			Equipment equipment = equipmentService.findSingleEquipment(repair.getEquipmentid());
			equipment.setStatus("0");
			equipmentService.updateEquipment(equipment);
		}
		return "redirect:/repair/findRepairAll";
	}

	@RequestMapping("/deleteRepair")
	public String deleteRepair(Integer repairId) {
		repairService.deleteRepair(repairId);
		return "redirect:/repair/findRepairAll";
	}
}
