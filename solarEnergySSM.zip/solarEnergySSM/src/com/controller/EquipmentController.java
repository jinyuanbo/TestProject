package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.Eqtype;
import com.model.Equipment;
import com.service.EqtypeService;
import com.service.EquipmentService;

@Controller
@RequestMapping("/equipment")
public class EquipmentController {

	@Autowired
	private EquipmentService equipmentService;
	
	@Autowired
	private EqtypeService eqtypeService;
	
	@RequestMapping("/findEquipmentAll")
	public String findEquipmentAll(HttpServletRequest request) {
		List<Equipment> equipmentList = equipmentService.findEquipmentAll();
		request.setAttribute("equipmentList", equipmentList);
		return "/equipment_list";
	}

	@RequestMapping("/beforeAddOrUpdateEquipment")
	public String beforeAddOrUpdateEquipment(Integer equipmentId, HttpServletRequest request) {
		Equipment equipment = new Equipment();
		if (equipmentId != null && !equipmentId.equals("")) {
			equipment = equipmentService.findSingleEquipment(equipmentId);
		}
		request.setAttribute("equipment", equipment);
		
		List<Eqtype> types = eqtypeService.findEqtypeAll();
		request.setAttribute("types", types);
		
		return "/equipment_addOrEdit";
	}

	@RequestMapping("/addOrUpdateEquipment")
	public String addOrUpdateEquipment(Equipment equipment) {
		if(equipment.getEquipmentid()==null){
			equipmentService.addEquipment(equipment);
		}else{
			equipmentService.updateEquipment(equipment);
		}
		return "redirect:/equipment/findEquipmentAll";
	}

	@RequestMapping("/deleteEquipment")
	public String deleteEquipment(Integer equipmentId) {
		equipmentService.deleteEquipment(equipmentId);
		return "redirect:/equipment/findEquipmentAll";
	}
}
