package com.dao;

import java.util.List;

import com.model.Eqtype;

public interface EqtypeMapper {
    int deleteByPrimaryKey(Integer eqtypeid);

    int insertSelective(Eqtype record);

    Eqtype selectByPrimaryKey(Integer eqtypeid);

    int updateByPrimaryKeySelective(Eqtype record);

	List<Eqtype> findEqtypeAll();
}