package com.dao;

import java.util.List;

import com.model.Equipment;

public interface EquipmentMapper {
    int deleteByPrimaryKey(Integer equipmentid);

    int insertSelective(Equipment record);

    Equipment selectByPrimaryKey(Integer equipmentid);

    int updateByPrimaryKeySelective(Equipment record);

	List<Equipment> findEquipmentAll();
}