package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.model.Task;

public interface TaskMapper {
    int deleteByPrimaryKey(Integer taskid);

    int insertSelective(Task record);

    Task selectByPrimaryKey(Integer taskid);

    int updateByPrimaryKeySelective(Task record);

	List<Task> findTaskAll(@Param("userid1")Integer userid1);
}