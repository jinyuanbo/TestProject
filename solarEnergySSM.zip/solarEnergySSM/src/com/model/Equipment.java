package com.model;

public class Equipment {
    private Integer equipmentid;

    private String imgurl;

    private String code;

    private Integer eqtypeid;

    private String electric;

    private String spec;

    private String brand;

    private String markettime;

    private String status;
    
    private Eqtype type;

    public Integer getEquipmentid() {
        return equipmentid;
    }

    public void setEquipmentid(Integer equipmentid) {
        this.equipmentid = equipmentid;
    }

    public String getImgurl() {
        return imgurl;
    }

    public void setImgurl(String imgurl) {
        this.imgurl = imgurl == null ? null : imgurl.trim();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    public Integer getEqtypeid() {
        return eqtypeid;
    }

    public void setEqtypeid(Integer eqtypeid) {
        this.eqtypeid = eqtypeid;
    }

    public String getElectric() {
        return electric;
    }

    public void setElectric(String electric) {
        this.electric = electric == null ? null : electric.trim();
    }

    public String getSpec() {
        return spec;
    }

    public void setSpec(String spec) {
        this.spec = spec == null ? null : spec.trim();
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand == null ? null : brand.trim();
    }

    public String getMarkettime() {
        return markettime;
    }

    public void setMarkettime(String markettime) {
        this.markettime = markettime == null ? null : markettime.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

	public Eqtype getType() {
		return type;
	}

	public void setType(Eqtype type) {
		this.type = type;
	}
    
}