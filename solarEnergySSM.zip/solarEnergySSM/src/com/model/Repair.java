package com.model;

public class Repair {
	private Integer repairid;
	
	private Integer equipmentid;

	private Integer userid1;

	private String addtime;

	private String content;

	private Integer userid2;

	private String reply;

	private String replytime;

	private User user1;

	private User user2;
	
	private Equipment equipment;

	public Integer getEquipmentid() {
		return equipmentid;
	}

	public void setEquipmentid(Integer equipmentid) {
		this.equipmentid = equipmentid;
	}

	public Integer getRepairid() {
		return repairid;
	}

	public void setRepairid(Integer repairid) {
		this.repairid = repairid;
	}

	public Integer getUserid1() {
		return userid1;
	}

	public void setUserid1(Integer userid1) {
		this.userid1 = userid1;
	}

	public String getAddtime() {
		return addtime;
	}

	public void setAddtime(String addtime) {
		this.addtime = addtime == null ? null : addtime.trim();
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content == null ? null : content.trim();
	}

	public Integer getUserid2() {
		return userid2;
	}

	public void setUserid2(Integer userid2) {
		this.userid2 = userid2;
	}

	public String getReply() {
		return reply;
	}

	public void setReply(String reply) {
		this.reply = reply == null ? null : reply.trim();
	}

	public String getReplytime() {
		return replytime;
	}

	public void setReplytime(String replytime) {
		this.replytime = replytime == null ? null : replytime.trim();
	}

	public User getUser1() {
		return user1;
	}

	public void setUser1(User user1) {
		this.user1 = user1;
	}

	public User getUser2() {
		return user2;
	}

	public void setUser2(User user2) {
		this.user2 = user2;
	}

	public Equipment getEquipment() {
		return equipment;
	}

	public void setEquipment(Equipment equipment) {
		this.equipment = equipment;
	}

}