package com.model;

public class Eqtype {
    private Integer eqtypeid;

    private String eqtypename;

    public Integer getEqtypeid() {
        return eqtypeid;
    }

    public void setEqtypeid(Integer eqtypeid) {
        this.eqtypeid = eqtypeid;
    }

    public String getEqtypename() {
        return eqtypename;
    }

    public void setEqtypename(String eqtypename) {
        this.eqtypename = eqtypename == null ? null : eqtypename.trim();
    }
}