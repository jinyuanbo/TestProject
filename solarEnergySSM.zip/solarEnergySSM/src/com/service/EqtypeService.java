package com.service;

import java.util.List;

import com.model.Eqtype;

public interface EqtypeService {

	List<Eqtype> findEqtypeAll();

	Eqtype findSingleEqtype(Integer id);

	int addEqtype(Eqtype obj);

	int updateEqtype(Eqtype obj);

	int deleteEqtype(Integer id);
}
