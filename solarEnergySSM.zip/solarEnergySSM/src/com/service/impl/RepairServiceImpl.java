package com.service.impl;

import com.dao.RepairMapper;
import com.model.Repair;
import com.service.RepairService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class RepairServiceImpl implements RepairService {

    @Resource
    private RepairMapper repairMapper;

    @Override
    public List<Repair> findRepairAll(Integer userid1) {
        return repairMapper.findRepairAll(userid1);
    }

    @Override
    public Repair findSingleRepair(Integer id) {
        return repairMapper.selectByPrimaryKey(id);
    }

    @Override
    public int addRepair(Repair obj) {
        return repairMapper.insertSelective(obj);
    }

    @Override
    public int updateRepair(Repair obj) {
        return repairMapper.updateByPrimaryKeySelective(obj);
    }

    @Override
    public int deleteRepair(Integer id) {
        return repairMapper.deleteByPrimaryKey(id);
    }
}
