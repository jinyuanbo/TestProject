package com.service.impl;

import com.dao.EqtypeMapper;
import com.model.Eqtype;
import com.service.EqtypeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class EqtypeServiceImpl implements EqtypeService {

    @Resource
    private EqtypeMapper eqtypeMapper;

    @Override
    public List<Eqtype> findEqtypeAll() {
        return eqtypeMapper.findEqtypeAll();
    }

    @Override
    public Eqtype findSingleEqtype(Integer id) {
        return eqtypeMapper.selectByPrimaryKey(id);
    }

    @Override
    public int addEqtype(Eqtype obj) {
        return eqtypeMapper.insertSelective(obj);
    }

    @Override
    public int updateEqtype(Eqtype obj) {
        return eqtypeMapper.updateByPrimaryKeySelective(obj);
    }

    @Override
    public int deleteEqtype(Integer id) {
        return eqtypeMapper.deleteByPrimaryKey(id);
    }
}
