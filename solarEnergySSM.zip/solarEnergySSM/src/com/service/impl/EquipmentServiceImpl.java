package com.service.impl;

import com.dao.EquipmentMapper;
import com.model.Equipment;
import com.service.EquipmentService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class EquipmentServiceImpl implements EquipmentService {

    @Resource
    private EquipmentMapper equipmentMapper;

    @Override
    public List<Equipment> findEquipmentAll() {
        return equipmentMapper.findEquipmentAll();
    }

    @Override
    public Equipment findSingleEquipment(Integer id) {
        return equipmentMapper.selectByPrimaryKey(id);
    }

    @Override
    public int addEquipment(Equipment obj) {
        return equipmentMapper.insertSelective(obj);
    }

    @Override
    public int updateEquipment(Equipment obj) {
        return equipmentMapper.updateByPrimaryKeySelective(obj);
    }

    @Override
    public int deleteEquipment(Integer id) {
        return equipmentMapper.deleteByPrimaryKey(id);
    }
}
