package com.service.impl;

import com.dao.TaskMapper;
import com.model.Task;
import com.service.TaskService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class TaskServiceImpl implements TaskService {

    @Resource
    private TaskMapper taskMapper;

    @Override
    public List<Task> findTaskAll(Integer userid1) {
        return taskMapper.findTaskAll(userid1);
    }

    @Override
    public Task findSingleTask(Integer id) {
        return taskMapper.selectByPrimaryKey(id);
    }

    @Override
    public int addTask(Task obj) {
        return taskMapper.insertSelective(obj);
    }

    @Override
    public int updateTask(Task obj) {
        return taskMapper.updateByPrimaryKeySelective(obj);
    }

    @Override
    public int deleteTask(Integer id) {
        return taskMapper.deleteByPrimaryKey(id);
    }
}
