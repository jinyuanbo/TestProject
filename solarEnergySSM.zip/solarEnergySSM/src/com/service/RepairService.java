package com.service;

import java.util.List;

import com.model.Repair;

public interface RepairService {

	List<Repair> findRepairAll(Integer userid1);

	Repair findSingleRepair(Integer id);

	int addRepair(Repair obj);

	int updateRepair(Repair obj);

	int deleteRepair(Integer id);
}
