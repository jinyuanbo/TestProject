package com.service;

import java.util.List;

import com.model.Task;

public interface TaskService {

	List<Task> findTaskAll(Integer userid1);

	Task findSingleTask(Integer id);

	int addTask(Task obj);

	int updateTask(Task obj);

	int deleteTask(Integer id);
}
