package com.service;

import java.util.List;

import com.model.Equipment;

public interface EquipmentService {

	List<Equipment> findEquipmentAll();

	Equipment findSingleEquipment(Integer id);

	int addEquipment(Equipment obj);

	int updateEquipment(Equipment obj);

	int deleteEquipment(Integer id);
}
